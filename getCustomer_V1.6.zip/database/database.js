
const mysql = require('mysql2');
const constant = require('../helper/constant');
process.env.hostUrl = constant.hostUrl;
process.env.user = constant.userName;
process.env.password = constant.password;
process.env.database = constant.databaseName;

/**
 *this function establishes the connection with Db instances 
 */
async function createConnection() {
    console.log("creating connection...");

    try {
        const connection = await mysql.createPool({
            host: process.env.hostUrl,
            user: process.env.user,
            password: process.env.password,
            database: process.env.database,
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0
        });

        return connection;
    } catch (error) {
        console.log("Error in creating connection");
        error.name = constant.auroraDbError;
        throw error;
    }

}

/**
 * this funnction will close connection
 * @param {*} connection 
 */
function closeConncetion(connection) {

    if (connection != undefined) {

        connection.releaseConnection();
    }
}

/**This function will getData from Aurora DB
 *  @param {*} phoneNumber 
 *  @param {*}  connection
 */
async function getCustomerData(phoneNumber, cust_id, connection) {

    if (connection != undefined) {

        try {

            const promisePool = connection.promise();
            var result;
            //qurying db
            if (phoneNumber != undefined) {

                result = [rows, fields] = await promisePool.query(constant.getCustomerQueryByPhoneNumber, [phoneNumber]);

            } else if (cust_id != undefined) {
                cust_id = parseInt(cust_id);
                result = [rows, fields] = await promisePool.query(constant.getCustomerQueryByCustId, [cust_id]);

            }
            return result;
        } catch (error) {
            console.log("Error in querying db", error);
            error.name = constant.queryFailedError;
            throw error;
        }
    } else {
        console.log("db connection error");
        error.name = constant.dbConnectionError;
        throw error;
    }

}


module.exports = {
    closeConncetion,
    createConnection,
    getCustomerData
}