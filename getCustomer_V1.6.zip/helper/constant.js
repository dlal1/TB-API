
//sql query
const getCustomerQueryByPhoneNumber = 'SELECT * FROM `customer_master_new` where PHONE_NUMBER=?';
const getCustomerQueryByCustId = 'SELECT * FROM `customer_master_new` where cust_id=?';
 
//custom errors
const auroraDbError = "auroraDb connection failed Error";
const dbConnectionError = "Error in db connection";
const queryFailedError = "Error while executing query";

//database credentials/information
const hostUrl = "localhost";
const userName = "root";
const password = "password";
const databaseName = "customer_database";

module.exports = {
    auroraDbError,
    getCustomerQueryByPhoneNumber,
    getCustomerQueryByCustId,
    dbConnectionError,
    queryFailedError,
    hostUrl,
    userName,
    password,
    databaseName

}