/**
 * This function dose response JSON formation 
 * @param {*} phoneNumber 
 * @param {*} data 
 */
function prepareData(phoneNumber, cust_id, data) {

    console.log("phoneNumber", phoneNumber, "cust_id", cust_id, "data", data);
    var response;
    if (data.length != 0) {
        var res = JSON.stringify(data[0]);
        res = JSON.parse(res);

        response = {
            statusCode: 200,
            statusText: "OK",
            headers: {
                "x-custom-header": "Records Found"
            },
            body: JSON.stringify(res)
        };
    } 
else {
        
        response = {
            statusCode: 404,
            statusText: "NO Data Found",
            headers: {
                "x-custom-header": "Records Not Found"
            },
            body: null,
        };
    }

    return response;
}



module.exports = {
    prepareData
}